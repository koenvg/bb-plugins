# OpenAI Codex speed for Pi

`@koenvg/pi-openai-codex-speed` 0.1.0 adds `/speed` to standalone Pi. It supports only Pi's native `openai-codex` ChatGPT subscription route. Token-audit remains a separate package.

## Commands

- `/speed` offers Default and account/model-confirmed Fast. Unavailable options are absent.
- `/speed default` selects ordinary provider behavior.
- `/speed fast` selects confirmed priority processing.
- `/speed ultrafast` rejects the selection in this version. No verified Ultrafast wire mapping exists in the inspected Codex client.
- `/speed refresh` reads capabilities again. It does not start a model turn.

The compact status shows the next selected speed. `!` means dispatch failed validation. Model, reasoning and editor contents do not change. A selection made during a running turn applies to the next turn. Tool continuations keep the turn's selection.

Fast can consume subscription usage differently. This package does not invent cost multipliers. It normalizes an advertised `Uses Nx usage.` sentence when present. Other descriptions use fixed safe text; arbitrary response prose never crosses a bridge. Pi retains native usage reporting.

## Availability and privacy

Discovery uses `ctx.modelRegistry.getApiKeyAndHeaders(model)` and `isUsingOAuth(model)` from the running Pi runtime. The account claim comes from that resolved token, using the same claim as Pi's Codex transport. It never opens credential files or a Codex CLI cache. The token and account ID remain inside the Pi process.

The authoritative request is `GET https://chatgpt.com/backend-api/codex/models?client_version=0.162.1`, with bearer auth and `ChatGPT-Account-ID`. Redirects are rejected. Discovery has a ten-second timeout and a two-MiB response limit. No response body, token, account ID, or token fingerprint is persisted or returned to callers. Errors expose fixed categories, not server text. The source and controller use private runtime state; serialize only method results.

The protocol adapter was checked against OpenAI Codex `rust-v0.162.1`:

- [Model-list request](https://github.com/openai/codex/blob/rust-v0.162.1/codex-rs/codex-api/src/endpoint/models.rs)
- [Model and service-tier response fields](https://github.com/openai/codex/blob/rust-v0.162.1/codex-rs/protocol/src/openai_models.rs)
- [Fast wire mapping](https://github.com/openai/codex/blob/rust-v0.162.1/codex-rs/protocol/src/config_types.rs)

A model's `service_tiers[].id === "priority"` confirms Fast. Model names, labels, `additional_speed_tiers`, catalog defaults, subscription plans, static Pi models and provider-wide declarations grant nothing. Unknown IDs, including `ultrafast`, grant nothing. Even a synthetic both-label fixture cannot prove a verified Ultrafast mapping or live entitlement. A later verified protocol adapter is needed to enable it.

Each controller retains at most one account-token-bound normalized snapshot for five minutes, and coalesces concurrent reads. First use, account/token change and standalone resume cause fresh discovery. Expiry and failed discovery grant no non-default tier until manual refresh. There is no polling, entitlement file, automatic refresh loop or discovery retry. Default never requires discovery.

## Dispatch and resume

The package decorates Pi's native provider, not its transport. It awaits existing payload instrumentation, then validates and sets the final `service_tier: "priority"`. Default removes tier injection and uses standard transport behavior. This final callback runs outside Pi's exception-swallowing extension event runner, before either HTTP or WebSocket setup. Stream events, tools, usage, cancellation, response instrumentation and native continuation handling remain delegated to Pi.

Pi 1.1.0 binds the payload callback to its low-level stream options. The wrapper sets the validated `serviceTier` on those options for native usage pricing. This is necessary because Pi's `streamSimple` adapter drops that option before request setup. Tests compare native priority and Default costs for both entry points, including missing or Default response-tier metadata. The package does not calculate its own pricing. New user-message boundaries, including queued follow-ups, take the next selection; tool-only continuations keep the previous selection.

Non-default HTTP requests disable native speculative retries. A server tier refusal is visible with no retry at another tier. Default keeps the native retry policy. Native WebSocket continuation recovery remains delegated and does not change the selected tier.

Standalone session entries contain only `{ speed }`, under `openai-codex-speed/preference-v1`. Resume and tree navigation restore the active branch's preference and invalidate capability evidence. A saved unconfirmed Fast or Ultrafast remains selected and cannot dispatch. Use an explicit supported selection, including Default, or successful refresh. There is no silent downgrade. A dispatch validation failure remains blocked until explicit selection or successful refresh.

Other routes have no non-default options and are not decorated. A saved Codex preference remains available when returning to Codex. Custom registered Codex providers are rejected with `unsupported-runtime` rather than replaced. Non-default use of custom endpoints or other APIs is unsupported.

## Registration ownership and BB consumption

The global standalone entry skips any runtime with `BB_THREAD_ID`, `BB_PROJECT_ID` or `BB_ENVIRONMENT_ID`. It also skips all RPC sessions, including a bundled BB bridge with a scrubbed environment. It therefore does not modify BB's bundled provider. Standalone TUI, print and JSON sessions are supported; non-UI sessions use explicit command arguments. This version deliberately has no automatic standalone RPC registration.

BB's `pi-subagents` generated extension must explicitly opt in inside its managed child's `session_start`:

```ts
import { installSpeed } from "@koenvg/pi-openai-codex-speed";

pi.on("session_start", (_event, ctx) => {
  const speed = installSpeed(pi, ctx, { ownership: "bb-managed" });
  // Keep this controller in the Pi child. Use it through the private channel.
});
```

`installSpeed` returns one `SpeedController` per model registry and installs the native guarded provider and turn lifecycle handlers. Repeated registration returns the same controller. BB-managed ownership does not register `/speed` or write standalone preference entries. The adapter owns BB persistence and channel operations. Separate Pi child runtimes start at Default; this package adds no inheritance.

Small shared interface:

```ts
await speed.capabilities(model);        // { tiers: [{ id, name, description }], error? }
await speed.refresh(model);             // explicit fresh discovery; same safe result
await speed.select(model, "fast");      // validates before accepting; no agent turn
speed.restore(savedPreference);        // restore BB preference; invalidates evidence
speed.selected;                        // default | fast | ultrafast
speed.blocked;                         // dispatch needs explicit choice or refresh
```

`select` throws `SpeedError` with a fixed `category`. Bridge only normalized tier metadata, selected speed, blocked state and error categories. Never bridge the controller, runtime, tokens or account identity. Validate in each running Pi child before prompt dispatch; a separate catalog child's result is not dispatch authority. The payload guard still revalidates before sending. Install the adapter before accepting prompts. Do not issue `/speed` as a synthetic chat turn.

For direct shared-module tests or embedding, `CapabilitySource(runtime, fetch?, now?)` and `SpeedController(source)` are exported. `decorate(nativeProvider)` delegates the supplied native transport. `installSpeed` is the supported Pi integration and rejects existing custom registrations. Host modules are peers, not bundled dependencies. Use the host's Pi loader module mapping when generating the BB extension.

Tested host version: Pi 1.1.0, Node 24.15.0. Peer ranges follow Pi's `*` manifest convention; other versions are not verified. BB compatibility is the adapter owner's responsibility. This package makes no BB SDK/core changes.

## Build and artifact

```sh
npm ci --ignore-scripts
npm run check
mkdir -p artifacts
npm pack --pack-destination artifacts
```

The artifact is `artifacts/koenvg-pi-openai-codex-speed-0.1.0.tgz`. It contains compiled ESM, declarations, README and license, with no absolute sibling-checkout dependency. BB can copy this versioned artifact into its owned build inputs and pin it. Do not install a second SDK instance. The artifact's host packages remain peers.

After separate installation approval, install the package directory or use Pi's pinned npm source once published. This implementation does not install globally, change user settings, publish, push or open a PR.

Model-free tests use sanitized fixtures and Pi's real native Codex transport with injected network adapters. Installed UI and live account acceptance are separate approval gates. No live account request or live Ultrafast test has been run. Roll back by explicitly selecting Default and restoring prior package versions. Keep session history and credentials.
